# JsAssignmentEvent

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**source** | **String** |  | 
**target** | **String** |  | 
**unassign_id** | **String** |  | 
**submitter** | **String** |  | 
**reassignment_counter** | **i64** |  | 
**created_event** | [**models::CreatedEvent**](CreatedEvent.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


