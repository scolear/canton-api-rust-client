# Command1

## Enum Variants

| Name | Description |
|---- | -----|
| Command1OneOf | A command can either create a new contract or exercise a choice on an existing contract. |
| Command1OneOf1 | A command can either create a new contract or exercise a choice on an existing contract. |
| Command1OneOf2 | A command can either create a new contract or exercise a choice on an existing contract. |

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


