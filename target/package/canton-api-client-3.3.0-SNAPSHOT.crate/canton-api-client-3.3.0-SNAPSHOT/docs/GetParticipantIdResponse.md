# GetParticipantIdResponse

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**participant_id** | **String** | Identifier of the participant, which SHOULD be globally unique. Must be a valid LedgerString (as describe in ``value.proto``). | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


