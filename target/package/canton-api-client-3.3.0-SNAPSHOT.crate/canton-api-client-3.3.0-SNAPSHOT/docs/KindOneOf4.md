# KindOneOf4

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**identity_provider_admin** | [**models::IdentityProviderAdmin**](IdentityProviderAdmin.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


