# PartyManagementFeature

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**max_parties_page_size** | **i32** | The maximum number of parties the server can return in a single response (page). | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


