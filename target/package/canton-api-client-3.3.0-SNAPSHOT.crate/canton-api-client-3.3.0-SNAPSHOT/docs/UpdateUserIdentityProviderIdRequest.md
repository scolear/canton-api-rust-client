# UpdateUserIdentityProviderIdRequest

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**user_id** | **String** | User to update | 
**source_identity_provider_id** | **String** | Current identity provider ID of the user | 
**target_identity_provider_id** | **String** | Target identity provider ID of the user | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


