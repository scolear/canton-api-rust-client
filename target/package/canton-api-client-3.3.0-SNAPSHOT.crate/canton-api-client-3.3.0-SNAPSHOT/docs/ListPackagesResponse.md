# ListPackagesResponse

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**package_ids** | Option<**Vec<String>**> | The IDs of all Daml-LF packages supported by the server. Each element must be a valid PackageIdString (as described in ``value.proto``). Required | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


