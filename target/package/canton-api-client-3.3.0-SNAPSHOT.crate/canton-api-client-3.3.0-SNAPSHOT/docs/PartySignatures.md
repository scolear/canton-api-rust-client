# PartySignatures

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**signatures** | Option<[**Vec<models::SinglePartySignatures>**](SinglePartySignatures.md)> | Additional signatures provided by all individual parties | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


