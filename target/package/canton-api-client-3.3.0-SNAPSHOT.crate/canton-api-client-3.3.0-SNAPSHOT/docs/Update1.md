# Update1

## Enum Variants

| Name | Description |
|---- | -----|
| Update1OneOf | The update that matches the filter in the request. |
| Update1OneOf1 | The update that matches the filter in the request. |
| Update1OneOf2 | The update that matches the filter in the request. |

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


