# Identifier

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**package_id** | **String** |  | 
**module_name** | **String** |  | 
**entity_name** | **String** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


