# JsArchived

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**archived_event** | [**models::ArchivedEvent**](ArchivedEvent.md) |  | 
**synchronizer_id** | **String** | Required The synchronizer which sequenced the archival of the contract | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


