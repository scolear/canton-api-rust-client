# JsSubmitAndWaitForTransactionRequest

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**commands** | [**models::JsCommands**](JsCommands.md) |  | 
**transaction_format** | [**models::TransactionFormat**](TransactionFormat.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


