# JsGetUpdateTreesResponse

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**update** | [**models::Update1**](Update1.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


