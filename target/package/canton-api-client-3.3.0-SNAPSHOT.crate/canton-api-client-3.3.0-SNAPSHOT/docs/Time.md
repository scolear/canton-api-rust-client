# Time

## Enum Variants

| Name | Description |
|---- | -----|
| TimeOneOf |  |
| TimeOneOf1 |  |
| TimeOneOf2 |  |

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


