# Recognized1

## Enum Variants

| Name | Description |
|---- | -----|
| ParticipantPermissionOneOf |  |
| ParticipantPermissionOneOf1 |  |
| ParticipantPermissionOneOf2 |  |
| ParticipantPermissionOneOf3 |  |

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


