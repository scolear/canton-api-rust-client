# TreeEventOneOf1

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**exercised_tree_event** | [**models::ExercisedTreeEvent**](ExercisedTreeEvent.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


