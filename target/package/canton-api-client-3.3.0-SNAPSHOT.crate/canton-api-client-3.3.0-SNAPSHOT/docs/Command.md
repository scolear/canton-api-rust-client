# Command

## Enum Variants

| Name | Description |
|---- | -----|
| CommandOneOf | A command can either create a new contract or exercise a choice on an existing contract. |
| CommandOneOf1 | A command can either create a new contract or exercise a choice on an existing contract. |
| CommandOneOf2 | A command can either create a new contract or exercise a choice on an existing contract. |
| CommandOneOf3 | A command can either create a new contract or exercise a choice on an existing contract. |

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


