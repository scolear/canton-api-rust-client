# IdentifierFilter

## Enum Variants

| Name | Description |
|---- | -----|
| IdentifierFilterOneOf |  |
| IdentifierFilterOneOf1 |  |
| IdentifierFilterOneOf2 |  |
| IdentifierFilterOneOf3 |  |

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


