# Update1OneOf

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**offset_checkpoint** | [**models::OffsetCheckpoint3**](OffsetCheckpoint3.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


