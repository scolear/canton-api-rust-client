# JsContractEntryOneOf

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**js_active_contract** | [**models::JsActiveContract**](JsActiveContract.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


