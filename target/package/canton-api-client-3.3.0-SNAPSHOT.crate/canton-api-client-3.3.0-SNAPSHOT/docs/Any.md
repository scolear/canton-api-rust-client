# Any

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**type_url** | **String** |  | 
**value** | **String** |  | 
**unknown_fields** | **String** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


