# ParticipantPermissionOneOf

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**participant_permission_confirmation** | [**serde_json::Value**](.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


