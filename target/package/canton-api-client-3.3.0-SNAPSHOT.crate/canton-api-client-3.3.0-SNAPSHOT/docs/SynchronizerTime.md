# SynchronizerTime

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**synchronizer_id** | **String** | The id of the synchronizer. Required | 
**record_time** | Option<**String**> | All commands with a maximum record time below this value MUST be considered lost if their completion has not arrived before this checkpoint. Required | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


