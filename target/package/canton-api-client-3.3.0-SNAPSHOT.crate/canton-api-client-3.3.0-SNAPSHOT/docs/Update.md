# Update

## Enum Variants

| Name | Description |
|---- | -----|
| UpdateOneOf | The update that matches the filter in the request. |
| UpdateOneOf1 | The update that matches the filter in the request. |
| UpdateOneOf2 | The update that matches the filter in the request. |
| UpdateOneOf3 | The update that matches the filter in the request. |

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


