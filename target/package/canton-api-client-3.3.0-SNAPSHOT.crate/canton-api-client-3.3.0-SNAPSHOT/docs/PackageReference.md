# PackageReference

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**package_id** | **String** | Required | 
**package_name** | **String** | Required | 
**package_version** | **String** | Required | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


