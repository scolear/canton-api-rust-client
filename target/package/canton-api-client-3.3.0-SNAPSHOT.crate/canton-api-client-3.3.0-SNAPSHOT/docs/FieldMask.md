# FieldMask

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**paths** | Option<**Vec<String>**> |  | [optional]
**unknown_fields** | **String** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


