# UpdateFormat

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**include_transactions** | Option<[**models::TransactionFormat**](TransactionFormat.md)> |  | [optional]
**include_reassignments** | Option<[**models::EventFormat**](EventFormat.md)> |  | [optional]
**include_topology_events** | Option<[**models::TopologyFormat**](TopologyFormat.md)> |  | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


