# ParticipantAuthorizationTopologyFormat

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**parties** | Option<**Vec<String>**> | List of parties for which the topology transactions should be sent. Empty means: for all parties. | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


