# RevokeUserRightsResponse

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**newly_revoked_rights** | Option<[**Vec<models::Right>**](Right.md)> | The rights that were actually revoked by the request. | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


