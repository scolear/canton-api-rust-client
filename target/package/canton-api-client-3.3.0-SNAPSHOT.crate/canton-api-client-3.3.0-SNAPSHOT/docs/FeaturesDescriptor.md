# FeaturesDescriptor

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**experimental** | Option<[**models::ExperimentalFeatures**](ExperimentalFeatures.md)> |  | [optional]
**user_management** | Option<[**models::UserManagementFeature**](UserManagementFeature.md)> |  | [optional]
**party_management** | Option<[**models::PartyManagementFeature**](PartyManagementFeature.md)> |  | [optional]
**offset_checkpoint** | Option<[**models::OffsetCheckpointFeature**](OffsetCheckpointFeature.md)> |  | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


