# TransactionFilter

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**filters_by_party** | [**std::collections::HashMap<String, models::Filters>**](Filters.md) |  | 
**filters_for_any_party** | Option<[**models::Filters**](Filters.md)> |  | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


