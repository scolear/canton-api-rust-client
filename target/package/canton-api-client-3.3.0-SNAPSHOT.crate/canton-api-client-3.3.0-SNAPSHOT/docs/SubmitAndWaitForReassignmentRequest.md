# SubmitAndWaitForReassignmentRequest

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**reassignment_commands** | Option<[**models::ReassignmentCommands**](ReassignmentCommands.md)> |  | [optional]
**event_format** | Option<[**models::EventFormat**](EventFormat.md)> |  | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


