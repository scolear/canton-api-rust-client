# TimeOneOf1

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**min_ledger_time_abs** | [**models::MinLedgerTimeAbs**](MinLedgerTimeAbs.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


