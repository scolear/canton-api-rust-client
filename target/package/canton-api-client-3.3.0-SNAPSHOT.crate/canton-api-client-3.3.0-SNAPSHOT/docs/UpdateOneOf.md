# UpdateOneOf

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**offset_checkpoint** | [**models::OffsetCheckpoint2**](OffsetCheckpoint2.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


