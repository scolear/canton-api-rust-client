# JsCreated

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**created_event** | [**models::CreatedEvent**](CreatedEvent.md) |  | 
**synchronizer_id** | **String** | The synchronizer which sequenced the creation of the contract Required | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


