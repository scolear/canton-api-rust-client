# DeduplicationPeriod2OneOf

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**deduplication_duration** | [**models::DeduplicationDuration2**](DeduplicationDuration2.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


