# GetPartiesResponse

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**party_details** | Option<[**Vec<models::PartyDetails>**](PartyDetails.md)> | The details of the requested Daml parties by the participant, if known. The party details may not be in the same order as requested. Required | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


