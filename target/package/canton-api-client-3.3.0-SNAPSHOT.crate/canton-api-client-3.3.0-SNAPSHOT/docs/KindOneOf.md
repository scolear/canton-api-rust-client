# KindOneOf

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**can_act_as** | [**models::CanActAs**](CanActAs.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


