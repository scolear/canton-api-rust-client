# ParticipantPermission

## Enum Variants

| Name | Description |
|---- | -----|
| ParticipantPermissionOneOf |  |
| ParticipantPermissionOneOf1 |  |
| ParticipantPermissionOneOf2 |  |
| ParticipantPermissionOneOf3 |  |
| ParticipantPermissionOneOf4 |  |
| ParticipantPermissionOneOf5 |  |

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


