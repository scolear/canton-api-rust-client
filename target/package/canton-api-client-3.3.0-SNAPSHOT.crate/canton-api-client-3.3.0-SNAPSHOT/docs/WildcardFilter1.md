# WildcardFilter1

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**include_created_event_blob** | **bool** | Whether to include a ``created_event_blob`` in the returned ``CreatedEvent``. Use this to access the contract create event payload in your API client for submitting it as a disclosed contract with future commands. Optional | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


