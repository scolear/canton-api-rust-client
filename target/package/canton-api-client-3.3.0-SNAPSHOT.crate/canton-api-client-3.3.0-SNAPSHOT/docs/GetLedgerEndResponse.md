# GetLedgerEndResponse

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**offset** | **i64** | It will always be a non-negative integer. If zero, the participant view of the ledger is empty. If positive, the absolute offset of the ledger as viewed by the participant. | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


