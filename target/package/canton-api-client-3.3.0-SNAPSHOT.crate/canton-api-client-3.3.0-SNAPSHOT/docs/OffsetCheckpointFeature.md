# OffsetCheckpointFeature

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**max_offset_checkpoint_emission_delay** | Option<[**models::Duration**](Duration.md)> |  | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


