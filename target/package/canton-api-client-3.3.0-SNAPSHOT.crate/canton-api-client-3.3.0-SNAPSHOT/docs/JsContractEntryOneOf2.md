# JsContractEntryOneOf2

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**js_incomplete_assigned** | [**models::JsIncompleteAssigned**](JsIncompleteAssigned.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


