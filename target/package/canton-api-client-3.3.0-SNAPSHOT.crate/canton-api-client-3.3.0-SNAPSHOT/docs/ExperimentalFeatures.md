# ExperimentalFeatures

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**static_time** | Option<[**models::ExperimentalStaticTime**](ExperimentalStaticTime.md)> |  | [optional]
**command_inspection_service** | Option<[**models::ExperimentalCommandInspectionService**](ExperimentalCommandInspectionService.md)> |  | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


