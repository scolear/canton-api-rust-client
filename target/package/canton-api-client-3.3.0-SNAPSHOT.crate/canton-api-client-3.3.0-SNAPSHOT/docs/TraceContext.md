# TraceContext

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**traceparent** | Option<**String**> | https://www.w3.org/TR/trace-context/ | [optional]
**tracestate** | Option<**String**> |  | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


