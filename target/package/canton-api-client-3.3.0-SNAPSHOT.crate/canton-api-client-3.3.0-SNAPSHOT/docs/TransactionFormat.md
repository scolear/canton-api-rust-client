# TransactionFormat

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**event_format** | Option<[**models::EventFormat**](EventFormat.md)> |  | [optional]
**transaction_shape** | [**models::TransactionShape**](TransactionShape.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


