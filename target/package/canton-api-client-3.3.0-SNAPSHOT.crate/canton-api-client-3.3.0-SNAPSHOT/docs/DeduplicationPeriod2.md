# DeduplicationPeriod2

## Enum Variants

| Name | Description |
|---- | -----|
| DeduplicationPeriod2OneOf | Specifies the deduplication period for the change ID. If omitted, the participant will assume the configured maximum deduplication time. |
| DeduplicationPeriod2OneOf1 | Specifies the deduplication period for the change ID. If omitted, the participant will assume the configured maximum deduplication time. |
| DeduplicationPeriod2OneOf2 | Specifies the deduplication period for the change ID. If omitted, the participant will assume the configured maximum deduplication time. |

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


