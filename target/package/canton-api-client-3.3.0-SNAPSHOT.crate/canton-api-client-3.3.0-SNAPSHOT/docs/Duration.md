# Duration

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**seconds** | **i64** |  | 
**nanos** | **i32** |  | 
**unknown_fields** | Option<**String**> | This field is automatically added as part of protobuf to json mapping | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


