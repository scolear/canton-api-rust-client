# TimeOneOf2

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**min_ledger_time_rel** | [**models::MinLedgerTimeRel**](MinLedgerTimeRel.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


